

/****** Object:  StoredProcedure [dbo].[IISsp_ListOfStocks]    Script Date: 1/11/2022 2:23:22 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
Created By:  BNR
Created On:  21-Oct-2022

Updated By:
Updated On:
Script Name: List of stocks
*/


-- IISsp_ListOfStocks 'ENS'
CREATE PROCEDURE [dbo].[IISsp_ListOfStocks]
@WhsCode as Varchar(100)
As
Begin
SET NOCOUNT ON

;WITH DRF_CTE
AS
-- Define the CTE query.
(
   select drf1.objtype, itemcode, whscode, sum(quantity) as quantity
           from DRF1 
           inner join odrf on odrf.DocEntry = DRF1.DocEntry and odrf.Objtype = DRF1.Objtype  and odrf.docstatus = 'O'		   
		   WHERE whscode = Case When isnull(@WhsCode,'ALL') = 'ALL' then whscode Else @WhsCode End
		   group by drf1.objtype, itemcode, whscode
),

Final_CTE
As 
(

SELECT 
T2.itemcode,
T3.ItemName,
T2.whscode,
--(Case When isnull(@WhsCode,'ALL') = 'ALL' then 'ALL' Else T2.whscode End) as whscode,
SUM(T2.onhand) as onhand,
SUM(T2.isCommited) as isCommited,
Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 59 and whscode=T2.whscode and itemcode=T2.itemcode ),0)  as 'DraftGoodsReceipt',
Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 60 and whscode=T2.whscode and itemcode=T2.itemcode ),0)  as 'DraftGoodsIssue',
Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 14 and whscode=T2.whscode and itemcode=T2.itemcode ),0)  as 'DraftCreditNote',
(
SUM(T2.onhand) - Sum(T2.isCommited)
+ Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 59 and whscode=T2.whscode and itemcode=T2.itemcode ),0) 
- Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 60 and whscode=T2.whscode and itemcode=T2.itemcode ),0)
+ Isnull((Select isnull(D.quantity,0) from  DRF_CTE as D where D.objtype = 14 and whscode=T2.whscode and itemcode=T2.itemcode ),0)
) as 'SOAvailable',
SUM(T2.onOrder) as onOrder
From  OITW T2 
inner join OITM T3 on T2.itemcode = T3.itemcode
WHERE T2.whscode = Case When isnull(@WhsCode,'ALL') = 'ALL' then T2.whscode Else @WhsCode End
--and T2.ItemCode ='A01-0011G0'
Group by 
T2.ItemCode, 
T3.itemname,
T2.whscode
--Case When isnull(@WhsCode,'ALL') = 'ALL' then 'ALL' Else T2.whscode End


)

SELECT
	 itemcode,
	 ItemName,
	 (Case When isnull(@WhsCode,'ALL') = 'ALL' then 'ALL' Else whscode End) as whscode,
	 SUM(onhand) as 'onhand',
	 SUM(isCommited) as 'isCommited',
	 SUM(DraftGoodsReceipt) as 'DraftGoodsReceipt',
	 SUM(DraftGoodsIssue) as 'DraftGoodsIssue',
	 SUM(DraftCreditNote) as 'DraftCreditNote',
	 SUM(SOAvailable) as 'SOAvailable',
	 SUM(onOrder) as 'onOrder'
FROM Final_CTE
WHERE whscode = Case When isnull(@WhsCode,'ALL') = 'ALL' then whscode Else @WhsCode End
Group by 
itemcode, 
ItemName,
Case When isnull(@WhsCode,'ALL') = 'ALL' then 'ALL' Else whscode End



End
GO


