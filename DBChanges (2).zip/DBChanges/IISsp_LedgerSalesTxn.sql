
/****** Object:  StoredProcedure [dbo].[IISsp_LedgerSalesTxn]    Script Date: 1/11/2022 2:24:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
Created By:  BNR
Created On:  21-Oct-2022

Updated By:
Updated On:
Script Name: List of stocks
*/


-- [IISsp_LedgerSalesTxn] 'A01-0011G1'
CREATE PROCEDURE [dbo].[IISsp_LedgerSalesTxn]
@itemcode as Varchar(100)
As
Begin
SET NOCOUNT ON

Select
		T1.DocDate  as DocDate, 
		convert(nvarchar(200),isnull(T1.DocNum,''))  as DocNum, 		
		'17' as TransType,
		T1.CardCode as CardCode, 
		T1.CardName as CardName,
		(CASE WHEN T2.Quantity < 0 THEN T2.Quantity ELSE 0 END) as  InQty,
        (CASE WHEN T2.Quantity > 0 THEN T2.Quantity ELSE 0 END) as  OutQty,		
		T2.Price as UnitPrice,
		T2.ItemCode as ItemCode,
		T1.CreateDate as CreatedOn, 
		T2.WhsCode as Location,
	    isnull(T2.BaseRef,'') as BASE_REF	
FROM
	ORDR T1 
	INNER JOIN  RDR1 T2 
		ON T1.DocEntry=T2.DocEntry and T2.ItemCode=@itemcode


End
GO


