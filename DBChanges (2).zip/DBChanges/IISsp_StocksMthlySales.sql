
/****** Object:  StoredProcedure [dbo].[IISsp_StocksMthlySales]    Script Date: 1/11/2022 2:25:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
Created By:  Rashmi Raju
Created On:  04-May-2017

Updated By:
Updated On:
Script Name: Income by Item Group
*/


-- [IISsp_StocksMthlySales] 'A01-0011G0'
CREATE PROCEDURE [dbo].[IISsp_StocksMthlySales]
@itemcode as Varchar(100)
As
Begin
SET NOCOUNT ON
Declare @DateFrom as DateTime
Declare @DateTo as DateTime 
Declare @CompName as Varchar(100)

Select @DateFrom = dateadd(Month,-23,getdate()),@DateTo= getdate()
--select @DateFrom
Select Top 1 @CompName = CompnyName From OADM 

--Get all Months for display
DECLARE 
      @Start DATE = @DateFrom
    , @End DATE = @DateTo
;WITH Period AS 
(
    SELECT Dt = DATEADD(DAY, -(DAY(@Start) - 1), @Start)

    UNION ALL

    SELECT DATEADD(MONTH, 1, dt)
    FROM Period
    WHERE Dt < DATEADD(DAY, -(DAY(@End) - 1), @End)
)


SELECT Distinct --SUBSTRING('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ', (MONTH(DT) * 4) - 3, 3) + '-' + RIGHT(Convert(Varchar,YEAR(DT)),2)  
Convert(Varchar,YEAR(DT))+ RIGHT('00'+CAST(MONTH(DT) AS NVARCHAR(2)),2) as PYear Into #Period
 FROM Period  

--Get the Year/Month List in Date Range
Declare @Month_list as varchar(max)
Select @Month_list = 
stuff(
(
Select ',[' + Convert(Varchar,PYear) + ']' from #Period for xml path('')
),1,1,'')
--select * From #Period
--Drop table #Period
--Select @Month_list


Select   Convert(Varchar,YEAR(T2.DocDate))+ RIGHT('00'+CAST(MONTH(T2.DocDate) AS NVARCHAR(2)),2) as MonthYr,
T1.Quantity--  ,@CompName as CompName 
into #Temp
From ORDR T2
Left Join RDR1 T1 on T1.DocEntry = T2.DocEntry 

Where Convert(Varchar,T2.DocDate,112) >=  Convert(Varchar,@DateFrom,112) and Convert(Varchar,T2.DocDate,112) <= Convert(Varchar,@DateTo,112) 
and T1.Itemcode = @itemcode


UNION ALL

Select  Convert(Varchar,YEAR(T2.DocDate))+ RIGHT('00'+CAST(MONTH(T2.DocDate) AS NVARCHAR(2)),2) as MonthYr,
-1*T1.Quantity-- ,@CompName as CompName 
From ORIN T2
left Join RIN1 T1 on T1.DocEntry = T2.DocEntry 
Where Convert(Varchar,T2.DocDate,112) >=  Convert(Varchar,@DateFrom,112) and Convert(Varchar,T2.DocDate,112) <= Convert(Varchar,@DateTo,112) 
and T1.Itemcode = @itemcode


--Declare @Dynamic_pivot_query as varchar(max)
--set @Dynamic_pivot_query = 'Select * 
--From ( Select * From #TEMP) as s
--Pivot
--(
--	Sum(Quantity) For [MonthYr] In (' + @Month_list +')
--)as p
--'
--exec(@Dynamic_pivot_query)
--Select * from #Period
--Select * from #TEmp
select #Period.PYear as MonthYr , convert(Varchar,isnull(Sum(Quantity),0.000)) as Quantity From 
#Period left join #TEmp on #TEmp.MonthYr = #Period.PYear   group by #Period.PYear
order by  #Period.PYear desc

Drop table #Period 
Drop table #TEMP 


End
GO


